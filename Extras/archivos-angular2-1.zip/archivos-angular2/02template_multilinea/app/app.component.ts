import { Component } from '@angular/core';

@Component({
    selector: 'my-app',
    template: `
    <h2>¡¡¡Hola Mundo con Angular 2!!!</h2>
    <p>Nuevo app con template multilinea</p>
    `
})

export class AppComponent {

}