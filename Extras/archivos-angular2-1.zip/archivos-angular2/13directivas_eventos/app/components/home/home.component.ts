import { Component } from '@angular/core';

@Component({
    selector: 'my-app',
    template: '<h1 EventsDirective>Primera directiva con Angular 2</h1>'
})
export class HomeComponent
{
    
}