import { Component } from '@angular/core';

@Component({
    selector: 'my-app',
    template: '<h2>¡¡¡Hola Mundo con Angular 2!!!</h2>'
})

export class AppComponent {

}