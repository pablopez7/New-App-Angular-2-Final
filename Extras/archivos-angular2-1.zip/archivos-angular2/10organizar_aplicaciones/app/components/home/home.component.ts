import { Component } from '@angular/core';

@Component({
    selector: 'my-app',
    template: '<h1>Organizar proyectos con Angular 2</h1>'
})
export class HomeComponent
{
    
}