import { Component } from '@angular/core';

@Component({
    selector: 'my-app',
    template: '<div class="container"><panel></panel></div>'
})
export class HomeComponent
{
    
}