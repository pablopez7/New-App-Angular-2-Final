"use strict";
var Post = (function () {
    function Post(id, title, content) {
        this.id = id;
        this.title = title;
        this.content = content;
    }
    return Post;
}());
exports.Post = Post;
//# sourceMappingURL=post.js.map